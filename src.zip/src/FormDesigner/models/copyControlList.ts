export const copyControlList = {
  ID_USERFORM1: {
    ID_USERFORM1: {
      properties: {
        BackColor: 'rgb(214, 213, 213,0.16)',
        BorderColor: '#ffffff',
        BorderStyle: 0,
        Caption: 'UserForm1',
        Cycle: 1,
        DrawBuffer: 32000,
        Enabled: true,
        Font: {
          FontName: 'Arial',
          FontSize: 10,
          FontBold: false,
          FontItalic: true,
          FontUnderline: true,
          FontStrikethrough: true,
          FontStyle: 'Arial Narrow Italic'
        },
        ForeColor: 'rgba(0,0,0,0.3)',
        Height: 350,
        HelpContextID: 0,
        KeepScrollBarsVisible: 3,
        Left: 0,
        MouseIcon: '',
        MousePointer: 0,
        Name: 'UserForm1',
        ID: 'ID_USERFORM1',
        Picture: '',
        PictureAlignment: 2,
        PictureSizeMode: 0,
        PictureTiling: false,
        RightToLeft: false,
        ScrollBars: 0,
        ScrollHeight: 0,
        ScrollLeft: 0,
        ScrollTop: 0,
        ScrollWidth: 0,
        ShowModal: true,
        SpecialEffect: 3,
        StartUpPosition: 1,
        Tag: '',
        Top: 0,
        Width: 700,
        WhatsThisButton: false,
        WhatsThisHelp: false,
        Zoom: 100
      },
      controls: [],
      extraDatas: {
        display: 'block'
      },
      type: 'Userform'
    }
  }
}
