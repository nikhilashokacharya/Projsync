export const colors = [
  {
    name: '&H00FFFFFF&',
    value: '#FFFFFF'
  },
  {
    name: '&H00C0C0FF&',
    value: '#FFBCBC'
  },
  {
    name: '&H00C0E0FF&',
    value: '#FFE3AE'
  },
  {
    name: '&H00C0FFFF&',
    value: '#FFFFA8'
  },
  {
    name: '&H00C0FFC0&',
    value: '#B5FFB5'
  },
  {
    name: '&H00FFFFC0&',
    value: '#CAF2FF'
  },
  {
    name: '&H00FFC0C0&',
    value: '#B8B8FF'
  },
  {
    name: '&H00FFC0FF&',
    value: '#FFC8FF'
  },
  {
    name: '&H00E0E0E0&',
    value: '#D3D3D3'
  },
  {
    name: '&H008080FF&',
    value: '#FDA5A5'
  },
  {
    name: '&H0080C0FF&',
    value: '#FFD586'
  },
  {
    name: '&H0080FFFF&',
    value: '#FFFF8A'
  },
  {
    name: '&H0080FF80&',
    value: '#86FF86'
  },
  {
    name: '&H00FFFF80&',
    value: '#84E0FF'
  },
  {
    name: '&H00FF8080&',
    value: '#8585FF'
  },
  {
    name: '&H00FF80FF&',
    value: '#FF82FF'
  },
  {
    name: '&H00C0C0C0&',
    value: '#AFAEAE'
  },
  {
    name: '&H000000FF&',
    value: '#FF7474'
  },
  {
    name: '&H000080FF&',
    value: '#FFC559'
  },
  {
    name: '&H0000FFFF&',
    value: '#FFFF6D'
  },
  {
    name: '&H0000FF00&',
    value: '#4DFF4D'
  },
  {
    name: '&H00FFFF00&',
    value: '#43D0FF'
  },
  {
    name: '&H00FF0000&',
    value: '#6666FF'
  },
  {
    name: '&H00FF00FF&',
    value: '#FF47FF'
  },
  {
    name: '&H00808080&',
    value: '#818080'
  },
  {
    name: '&H000000C0&',
    value: '#FF4A4A'
  },
  {
    name: '&H000040C0&',
    value: '#FFBA3A'
  },
  {
    name: '&H0000C0C0&',
    value: '#FFFF48'
  },
  {
    name: '&H0000C000&',
    value: '#00FF00'
  },
  {
    name: '&H00C0C000&',
    value: '#00BFFF'
  },
  {
    name: '&H00C00000&',
    value: '#3A3AFF'
  },
  {
    name: '&H00C000C0&',
    value: '#FF07FF'
  },
  {
    name: '&H00404040&',
    value: '#414040'
  },
  {
    name: '&H00000080&',
    value: '#FF2929'
  },
  {
    name: '&H00004080&',
    value: '#FFB01D'
  },
  {
    name: '&H00008080&',
    value: '#FFFF23'
  },
  {
    name: '&H00008000&',
    value: '#3ACC3A'
  },
  {
    name: '&H00808000&',
    value: '#4B93AC'
  },
  {
    name: '&H00800000&',
    value: '#3030CA'
  },
  {
    name: '&H00800080&',
    value: '#AF3EAF'
  },
  {
    name: '&H00000000&',
    value: '#1A1919'
  },
  {
    name: '&H00000040&',
    value: '#FF0000'
  },
  {
    name: '&H00404080&',
    value: '#FFA600'
  },
  {
    name: '&H00004040&',
    value: '#FFFF00'
  },
  {
    name: '&H00004000&',
    value: '#2BA12B'
  },
  {
    name: '&H00404000&',
    value: '#0A5E7A'
  },
  {
    name: '&H00400000&',
    value: '#1F1F6D'
  },
  {
    name: '&H00400040&',
    value: '#702970'
  },
  {
    name: '&H00FFFFFF&',
    value: '#FFFFFF'
  },
  {
    name: '&H00FFFFFF&',
    value: '#FFFFFF'
  },
  {
    name: '&H00FFFFFF&',
    value: '#FFFFFF'
  },
  {
    name: '&H00FFFFFF&',
    value: '#FFFFFF'
  },
  {
    name: '&H00FFFFFF&',
    value: '#FFFFFF'
  },
  {
    name: '&H00FFFFFF&',
    value: '#FFFFFF'
  },
  {
    name: '&H00FFFFFF&',
    value: '#FFFFFF'
  },
  {
    name: '&H00FFFFFF&',
    value: '#FFFFFF'
  },
  {
    name: '&H00FFFFFF&',
    value: '#FFFFFF'
  },
  {
    name: '&H00FFFFFF&',
    value: '#FFFFFF'
  },
  {
    name: '&H00FFFFFF&',
    value: '#FFFFFF'
  },
  {
    name: '&H00FFFFFF&',
    value: '#FFFFFF'
  },
  {
    name: '&H00FFFFFF&',
    value: '#FFFFFF'
  },
  {
    name: '&H00FFFFFF&',
    value: '#FFFFFF'
  },
  {
    name: '&H00FFFFFF&',
    value: '#FFFFFF'
  },
  {
    name: '&H00FFFFFF&',
    value: '#FFFFFF'
  }
]
