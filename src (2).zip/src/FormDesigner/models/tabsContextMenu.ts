export const tabsContextMenu = [
  {
    id: 'ID_NEWPAGE',
    icon: '',
    text: '<u>N</u>ew Page',
    values: [],
    disabled: false
  },
  {
    id: 'ID_DELETEPAGE',
    icon: '',
    text: '<u>D</u>elete Page',
    values: [],
    disabled: false
  },
  {
    id: 'ID_RENAME',
    icon: '',
    text: '<u>R</u>ename...',
    values: [],
    disabled: false
  },
  {
    id: 'ID_MOVE',
    icon: '',
    text: '<u>M</u>ove...',
    values: [],
    disabled: false
  }
]
